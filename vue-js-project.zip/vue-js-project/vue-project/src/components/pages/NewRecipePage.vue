<template>
    <div class="container-md my-5 py-5">
        <recipe-form></recipe-form>
    </div>
</template>

<script setup>
import RecipeForm from '../recipeForm/RecipeForm.vue';
</script>