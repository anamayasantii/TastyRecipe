<template>
  <main>
    <div class="container-md my-5 py-5">
      <recipe-form
        v-if="detailData && !isLoading" :isEdit="true"> 
      </recipe-form>
    </div>
  </main>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";
import { useStore } from "vuex";
import RecipeForm from "../recipeForm/RecipeForm.vue";
import RecipeFormBody from "../recipeForm/RecipeFormBody.vue";

const store = useStore();
const route = useRoute();
const detailData = ref(null);

let isLoading = false;

onMounted(async () => {
  try {
    isLoading = true;
    await store.dispatch("recipe/getRecipeDetail", route.params.id);
    detailData.value = store.state.recipe.recipeDetail;

  } catch (err) {
    console.error(err);
  }
  isLoading = false;
});
</script>
