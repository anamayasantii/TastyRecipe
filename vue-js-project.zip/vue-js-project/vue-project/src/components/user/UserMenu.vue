<template>
    <div class="col-lg-3 mb-4">
      <ul class="list-group">
        <li class="list-group-item">
          <div class="d-flex align-items-center">
          <img :src="userData.imageLink" alt="Profile"
              width="36" height="36" class="rounded-circle" style="object-fit:cover"
          />
          <div class="ps-3">
              <p class="my-0 fs-5 fw-semibold">
                  {{  userData.firstname }} {{  userData.lastname }}
              </p>
              <p class="my-0 fs-6 text-secondary">
                  {{  userData.email }}
              </p>
          </div>
          </div>
        </li>
        <li class="list-group-item user-menu"
        @click="menuClicked('personal-info')">
          <i class="fa-solid fa-user pe-2"></i>Personal Info
        </li>
        <li class="list-group-item user-menu"
        @click="menuClicked('favorite-recipes')">
          <i class="fas fa-heart pe-2"></i>Favorited Recipes
        </li>
        <li class="list-group-item user-menu"
        @click="menuClicked('user-recipe')">
          <i class="fa-solid fa-burger pe-2"></i>My Recipe
        </li>
      </ul>
    </div>
  </template>
  
  <style scoped>
  .user-menu:hover {
    cursor: pointer;
  }
  
  .active-color {
    color: #4c4ddc;
  }
  
  .inactive-color {
    color: #404040;
  }
  </style>

<script setup>
const emit = defineEmits(['changeComponent'])
import { computed } from "vue";
import { useStore } from "vuex";

const menuClicked = option => {
    // emit("changeComponent", `user/${option}`) //Modifikasi Logika Navigasi: 
    //Ketika mengeluarkan opsi menu yang dipilih, pastikan untuk menambahkan 
    //awalan jalur yang benar untuk navigasi.
    emit("changeComponent", option)
}

const store = useStore()
const userData = computed(() => {
    return store.state.auth.userLogin
})
</script>