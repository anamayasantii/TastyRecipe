<template>
    <ul class="list-group">
        <recipe-form-header></recipe-form-header>
        <recipe-form-body :isEdit="isEdit"></recipe-form-body>
    </ul>
</template>

<script setup>
import RecipeFormHeader from './RecipeFormHeader.vue';
import RecipeFormBody from './RecipeFormBody.vue';
import EditRecipePage from '../pages/EditRecipePage.vue';

defineProps({
  isEdit:{ type: Boolean, require: false },
})
</script>